package ro.pub.cs.lcpl;

/* <expression> / <expression> */

public class Division extends BinaryOp {
	public Division(int lineNumber, Expression e1, Expression e2) {
		super(lineNumber, e1, e2);
	}

}
