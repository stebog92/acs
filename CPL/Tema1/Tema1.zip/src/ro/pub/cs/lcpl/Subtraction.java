package ro.pub.cs.lcpl;

/* <expression> - <expression> */

public class Subtraction extends BinaryOp {

	public Subtraction(int lineNumber, Expression e1, Expression e2) {
		super(lineNumber, e1, e2);
	}

}
