package ro.pub.cs.lcpl;

/* A method or attribute of a class */

public interface Feature {

}
