package ro.pub.cs.lcpl;

/* <expression> == <expression> */

public class EqualComparison extends BinaryOp {

	public EqualComparison(int lineNumber, Expression e1, Expression e2) {
		super(lineNumber, e1, e2);
	}

}
