package ro.pub.cs.lcpl;

/* the constant "void" */

public class VoidConstant extends Expression {

	public VoidConstant(int lineNumber) {
		super(lineNumber);
	}

}
