package ro.pub.cs.lcpl;

/* ! <expression> */

public class LogicalNegation extends UnaryOp {

	public LogicalNegation(int lineNumber, Expression e1) {
		super(lineNumber, e1);
	}

}
