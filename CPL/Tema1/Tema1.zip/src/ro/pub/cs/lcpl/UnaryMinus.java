package ro.pub.cs.lcpl;

/* - <expression>, in unary operator context */

public class UnaryMinus extends UnaryOp {

	public UnaryMinus(int lineNumber, Expression e1) {
		super(lineNumber, e1);
	}

}
