package ro.pub.cs.lcpl;

/* <expression> * <expression> */

public class Multiplication extends BinaryOp {

	public Multiplication(int lineNumber, Expression e1, Expression e2) {
		super(lineNumber, e1, e2);
	}

}
