package ro.pub.cs.lcpl;

/* <expression> < <expression> */

public class LessThan extends BinaryOp {

	public LessThan(int lineNumber, Expression e1, Expression e2) {
		super(lineNumber, e1, e2);
	}

}
