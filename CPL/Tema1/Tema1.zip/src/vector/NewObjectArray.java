package vector;
import ro.pub.cs.lcpl.*;

public class NewObjectArray extends UnaryBracket {

	public NewObjectArray  (int lineNumber, Expression type, Expression size) {
		super(lineNumber,type, size);
	}

}
