package vector;

import ro.pub.cs.lcpl.*;

public class ArrayAccess extends UnaryBracket {

	public ArrayAccess(int lineNumber, Expression type, Expression size) {
		super(lineNumber,type, size);
	}

}
