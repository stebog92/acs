package vector;

import ro.pub.cs.lcpl.*;

public class AttributeArray extends Attribute {
	
	public AttributeArray(int lineNumber, String name, String type, Expression init) {
		super(lineNumber, name, type, init);
	}
	
}
