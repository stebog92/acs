package ro.pub.cs.lcpl;

/** Type for the constant "void" */
public class NullType implements Type {

	@Override
	public String getName() {
		return "void";
	}

}
