package ro.pub.cs.lcpl;

/** Describes a type. Could be a class, Int, the 'void' constant, or none 
 *  */
public interface Type {
	public String getName();
}
