package ro.pub.cs.lcpl;

/** ! <i>expression</i> */
public class LogicalNegation extends UnaryOp {

	public LogicalNegation(int lineNumber, Expression e1) {
		super(lineNumber, e1);
	}

	public LogicalNegation() {}
	
}
