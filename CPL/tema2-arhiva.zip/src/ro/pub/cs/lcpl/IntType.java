package ro.pub.cs.lcpl;

/** Describes the Int type */
public class IntType implements Type {
	@Override
	public String getName() {
		return TreeNode.KWD_INT;
	}
}
