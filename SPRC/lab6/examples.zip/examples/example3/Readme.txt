/**
	Sisteme de programe pentru retele de calculatoare
	
	Copyright (C) 2008 Ciprian Dobre & Florin Pop
	Univerity Politehnica of Bucharest, Romania

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
 */

Laborator 3. Consistenta datelor si toleranta la defecte.

     Listing 3. Exemplu de implementare a unui client de NTP.
     
     In cadrul exemplului se ilustreaza o posibila implementare a unui client de NTP.
     Un astfel de client poate fi incorporat in cadrul unei aplicatii pentru a sincroniza
     comunicatiile, in cadrul diverselor operatii de asigurare a consistentei datelor sau de
     ordonare a operatiilor executate de catre mai multe procese distribuite.
     
     Pentru mai multe detalii se pot consulta explicatiile din fisierele sursa. Rularea aplicatiei se realizeaza cu ant.
     
 