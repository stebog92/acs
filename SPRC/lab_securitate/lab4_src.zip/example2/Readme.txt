/**
	Sisteme de programe pentru retele de calculatoare
	
	Copyright (C) 2008 Ciprian Dobre & Florin Pop
	Univerity Politehnica of Bucharest, Romania

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
 */

Capitolul V. Securitate in Java.

Listing 2. Exemplu de criptare/decriptare folosind chei simetrice. 
 
Aplicatia prezinta o solutie pentru criptarea/decriptarea datelor in Java (folosind 
algoritmul DES). Aplicatia poate fi apelata cu optiunea -e (criptare) sau -d (decriptare).

Executia aplicatiei:

'ant encrypt' - lanseaza un test de criptare
'ant decrypt' - lanseaza un test de decriptare
