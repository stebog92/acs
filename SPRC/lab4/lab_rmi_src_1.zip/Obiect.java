/**
 * 
 */
package curs4;

import java.io.Serializable;

/**
 * @author FlorinPop
 *
 */
public class Obiect implements Serializable {
	private static final long serialVersionUID = 241020081755L;

	public Obiect(){
		System.out.println("Constructor: Sunt obiect serializabil.");
	}
}
