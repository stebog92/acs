/**
 * 
 */
package curs5;

/**
 * @author FlorinPop
 *
 */

public interface ServerPisicaInterf extends java.rmi.Remote {
	PisicaInterf referintaPisica() throws java.rmi.RemoteException;
}
