package curs5;

public interface PisicaInterf extends java.rmi.Remote {
	public PisicaObisnuita obtinePisica() throws java.rmi.RemoteException;
}
