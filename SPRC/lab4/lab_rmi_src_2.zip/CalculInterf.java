/**
 * 
 */
package curs5;

/**
 * @author FlorinPop
 *
 */
public interface CalculInterf {
	int efectueazaCalcul(int x, int y);
}
