import java.util.Scanner;

public interface Readable 
{
  public void read(Scanner scanner);
}
