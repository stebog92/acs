#pragma once
#include <cstdlib>
#include "dependinte\freeglut.h"
#include <iostream>
#include "Support3d.h"

#define KEY_DOWN GLUT_KEY_DOWN
#define KEY_LEFT GLUT_KEY_LEFT
#define KEY_UP GLUT_KEY_UP
#define KEY_RIGHT GLUT_KEY_RIGHT
#define KEY_ESC 27
#define KEY_SPACE 32
