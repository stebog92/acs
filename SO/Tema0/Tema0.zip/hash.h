
#ifndef _HASH_H
#define _HASH_H

unsigned int hash(const char *str, unsigned int hash_length);

#endif

