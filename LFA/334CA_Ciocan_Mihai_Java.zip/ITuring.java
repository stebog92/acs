
public interface ITuring {
	public void execute();
	public State getLastState();
	public String toString();
}
